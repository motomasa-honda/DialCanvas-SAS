/* P4 executable control/BSP integration, review build; not the full Web/dial product. */
#include <string.h>
#include <stdlib.h>
#include <math.h>
#include <stdatomic.h>
#include <time.h>
#include <sys/time.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "driver/gpio.h"
#include "driver/i2c_master.h"
#include "esp_timer.h"
#include "esp_log.h"
#include "nvs_flash.h"
#include "bsp/esp-bsp.h"
#include "lvgl.h"
#include "control.h"
#include "fg_board_pins.h"
#include "fg_time.h"
#include "fg_intent.h"
#include "fg_output_guard.h"
#include "fg_journal.h"
#include "fg_clock.h"
#include "fg_tzif.h"
#include "fg_tz_default.h"
#include "nvs.h"
#include "freertos/queue.h"
#define ARM FG_PIN_ARM
#define HB FG_PIN_HEARTBEAT
#define FAULT FG_PIN_FAULT
#define SW1 FG_PIN_SW1
#define SW2 FG_PIN_SW2
static const char *TAG="forest_guardian";
static i2c_master_dev_handle_t mcp[2],rtc;
static fg_control ctl;
/* RTC clock seed; SNTP producer and provisioned timezone DB remain disabled. */
static fg_clock utc_clock;
static fg_tzif display_timezone;
static bool display_timezone_valid;
/* Bounded request mailbox: only the control task consumes intents. Network
   endpoints are NOT enabled in this review build. */
static QueueHandle_t intent_queue;
static QueueHandle_t journal_queue;
static fgp_fault_ring persisted_faults;
static atomic_bool fault_journal_write_failed;
static atomic_int shown_state;
static atomic_int shown_fault;
static atomic_uint motor_mask,light_mask;
static atomic_bool clock_valid;
static atomic_bool status_page,pairing_requested;
static lv_obj_t *clock_label,*state_label,*status_label;
static lv_obj_t *hands[3];
static lv_point_precise_t hand_points[3][2];
static esp_err_t put(i2c_master_dev_handle_t dev,uint8_t reg,const uint8_t *data,size_t n){
 uint8_t b[9];if(n>8)return ESP_ERR_INVALID_SIZE;b[0]=reg;memcpy(b+1,data,n);return i2c_master_transmit(dev,b,n+1,10);
}
static esp_err_t get(i2c_master_dev_handle_t dev,uint8_t reg,uint8_t *data,size_t n){return i2c_master_transmit_receive(dev,&reg,1,data,n,10);}
static bool apply(const uint8_t want[4]){
 uint8_t got[4];
 for(unsigned i=0;i<2;i++)if(put(mcp[i],0x14,want+2*i,2)!=ESP_OK)return false;
 for(unsigned i=0;i<2;i++)if(get(mcp[i],0x14,got+2*i,2)!=ESP_OK)return false;
 return memcmp(got,want,4)==0;
}
static bool bus_init(void){
 i2c_master_bus_config_t b={.i2c_port=I2C_NUM_1,.sda_io_num=FG_PIN_MCP_SDA,.scl_io_num=FG_PIN_MCP_SCL,.clk_source=I2C_CLK_SRC_DEFAULT,.glitch_ignore_cnt=7,.flags.enable_internal_pullup=false};
 i2c_master_bus_handle_t bus;if(i2c_new_master_bus(&b,&bus)!=ESP_OK)return false;
 for(unsigned i=0;i<3;i++){
  i2c_device_config_t d={.dev_addr_length=I2C_ADDR_BIT_LEN_7,.device_address=i<2?(0x20+i):0x32,.scl_speed_hz=100000};
  if(i2c_master_bus_add_device(bus,&d,i<2?&mcp[i]:&rtc)!=ESP_OK)return false;
 }
 uint8_t zero[2]={0,0},desired[4];fg_ports(&ctl,desired);
 for(unsigned i=0;i<2;i++){
  /* Supply supervisor resets BANK=0 before this boot initialization. */
  if(put(mcp[i],0x0a,zero,2)!=ESP_OK||put(mcp[i],0x14,desired+2*i,2)!=ESP_OK||put(mcp[i],0x00,zero,2)!=ESP_OK)return false;
 }
 return apply(desired);
}
static void fail(const char *why){gpio_set_level(ARM,0);fg_fail(&ctl,why);uint8_t p[4];fg_ports(&ctl,p);(void)apply(p);ESP_LOGE(TAG,"Fault: %s",why);}
/* Bounded recovery probe, always ARM=0 and motor OLAT=0; each HB follows readback.
   It allows the watchdog startup/reset interval to release without an automatic START. */
static bool recovery_probe(void){
 gpio_set_level(ARM,0);ctl.arm=false;memset(ctl.phase,0,7);
 uint64_t start=esp_timer_get_time(),last=0;bool h=false;
 while((uint64_t)esp_timer_get_time()-start<500000){
  uint8_t p[4];fg_ports(&ctl,p);if(!apply(p))return false;
  uint64_t now=esp_timer_get_time();if(now-last>=50000){h=!h;gpio_set_level(HB,h);last=now;}
  if(now-start>=100000 && gpio_get_level(FAULT)){ctl.hb=h;ctl.last_hb=last;return true;}
  vTaskDelay(pdMS_TO_TICKS(5));
 }
 return false;
}
/* Use the tested Phase51 RX8900 UTC validator, not the previous ad-hoc BCD parser. */
static void read_clock(void){
 uint8_t flags,raw[7];fg_utc_time utc;int64_t seconds;
 atomic_store(&clock_valid,false);
 if(get(rtc,0x1e,&flags,1)!=ESP_OK || get(rtc,0x10,raw,7)!=ESP_OK ||
    !fg_time_decode_rx8900(raw,flags,&utc)||!fg_time_unix_utc(utc,&seconds))return;
 struct timeval tv={.tv_sec=(time_t)seconds,.tv_usec=0};
 if(fg_clock_set_rtc(&utc_clock,utc,(uint64_t)esp_timer_get_time()/1000U) &&
    settimeofday(&tv,NULL)==0)atomic_store(&clock_valid,true);
}
static int fault_number(const char *fault){
 static const char *codes[]={"physical_fault","bus_init","startup_health","bus_readback","phase_deadline","multiple_phase"};
 if(!fault)return 0;
 for(unsigned i=0;i<sizeof(codes)/sizeof(codes[0]);i++){
  if(!strcmp(fault,codes[i]))return (int)i+1;
 }
 return 7;
}
static bool guard_fault_ok(void *ctx){(void)ctx;return gpio_get_level(FAULT)!=0;}
static bool guard_apply(void *ctx,const uint8_t p[4]){(void)ctx;return apply(p);}
static void guard_arm(void *ctx,bool enabled){(void)ctx;gpio_set_level(ARM,enabled?1:0);}
static const fg_output_io output_ops={.context=NULL,.fault_healthy=guard_fault_ok,
 .verified_apply=guard_apply,.write_arm=guard_arm};
/* The NVS writer is a separate task; no flash I/O enters the 5ms control loop. */
static bool journal_read(void *ctx,unsigned slot,uint8_t *dst,size_t n){
 (void)ctx;nvs_handle_t handle;
 if(nvs_open("fgfault",NVS_READONLY,&handle)!=ESP_OK)return false;
 const char *key=slot==0?"slot0":"slot1";size_t len=n;
 esp_err_t err=nvs_get_blob(handle,key,dst,&len);nvs_close(handle);
 return err==ESP_OK&&len==n;
}
static bool journal_write(void *ctx,unsigned slot,const uint8_t *src,size_t n){
 (void)ctx;nvs_handle_t handle;
 if(nvs_open("fgfault",NVS_READWRITE,&handle)!=ESP_OK)return false;
 const char *key=slot==0?"slot0":"slot1";
 esp_err_t err=nvs_set_blob(handle,key,src,n);
 if(err==ESP_OK)err=nvs_commit(handle);
 nvs_close(handle);return err==ESP_OK;
}
static const fg_journal_io journal_io={.context=NULL,.read=journal_read,.write=journal_write};
static void journal_task(void *unused){
 (void)unused;fgp_fault_ring snapshot;
 for(;;){
  if(xQueueReceive(journal_queue,&snapshot,portMAX_DELAY)==pdTRUE){
   if(!fg_journal_commit(&journal_io,&snapshot)){
    atomic_store(&fault_journal_write_failed,true);
    ESP_LOGE(TAG,"Fault history NVS commit failed");
   }
  }
 }
}
static void record_fault_once(uint64_t uptime_us,int prior_state){
 fgp_fault_ring *r=&persisted_faults;
 fgp_fault_event *e=&r->item[r->next];
 struct timeval tv={0};
 int64_t utc=-1;
 if(atomic_load(&clock_valid)&&gettimeofday(&tv,NULL)==0)utc=(int64_t)tv.tv_sec;
 *e=(fgp_fault_event){.monotonic_ms=uptime_us/1000U,.utc_seconds=utc,
  .fault_code=(uint32_t)fault_number(ctl.fault),
  .hw_power_good=0, /* physical PG level not available on current D7 pins */
  .hw_fault=(uint8_t)gpio_get_level(FAULT),.prior_state=(uint8_t)prior_state};
 r->next=(r->next+1)%FG_FAULT_CAPACITY;
 if(r->count<FG_FAULT_CAPACITY)r->count++;
 if(xQueueSend(journal_queue,r,0)!=pdTRUE)atomic_store(&fault_journal_write_failed,true);
}
static void control_task(void *unused){
 (void)unused;bool available=bus_init();if(!available)fg_fail(&ctl,"bus_init");
 else if(recovery_probe())fg_boot_ok(&ctl);else fg_fail(&ctl,"startup_health");
 if(available)read_clock();
 uint64_t seq=0;bool previous_fault=false;int previous_state=ctl.state;
 fg_buttons buttons;fg_buttons_init(&buttons,esp_timer_get_time());TickType_t tick=xTaskGetTickCount();
 for(;;){
  uint64_t now=esp_timer_get_time();
  /* At most two non-blocking requests/tick. Health is rechecked at consumption. */
  fg_intent intent;
  for(unsigned j=0;j<2&&intent_queue&&xQueueReceive(intent_queue,&intent,0)==pdTRUE;j++){
   fg_intent_context ctx={.now_us=now,
    .hardware_healthy=available&&gpio_get_level(FAULT),
    .arm_is_low=!ctl.arm && !gpio_get_level(ARM)};
   (void)fg_intent_apply(&ctl,&intent,ctx);
  }
  fg_button_action action=fg_buttons_update(&buttons,!gpio_get_level(SW1),!gpio_get_level(SW2),now);
  if(action==FG_BUTTON_VIEW_TOGGLE)atomic_store(&status_page,!atomic_load(&status_page));
  else if(action==FG_BUTTON_MOTORS_TOGGLE){
   if(ctl.state==FG_RUN||ctl.state==FG_STARTING)fg_stop(&ctl);
   else if(ctl.state==FG_FAULT){if(available&&recovery_probe())(void)fg_clear(&ctl,true,true);}
   else if(ctl.state==FG_OFF){
    /* Keep physical and authenticated request sequences in the same monotonic domain. */
    if(ctl.last_sequence<UINT64_MAX-1){seq=ctl.last_sequence+1;
     (void)fg_start(&ctl,seq,now,true,available&&gpio_get_level(FAULT));}
   }
  }else if(action==FG_BUTTON_LIGHTS_TOGGLE){ctl.led[0]=!ctl.led[0];ctl.led[1]=ctl.led[0];}
  else if(action==FG_BUTTON_REQUEST_PAIRING){
   fg_stop(&ctl);gpio_set_level(ARM,0);
   atomic_store(&pairing_requested,ctl.state==FG_OFF&&!ctl.arm);
   /* The safe physical request is implemented; AP/TLS provisioning remains open. */
  }
  if(available&&(ctl.state==FG_OFF||ctl.state==FG_RUN||ctl.state==FG_STARTING)){
   fg_prepare(&ctl,esp_timer_get_time(),gpio_get_level(FAULT));
   if(fg_output_commit(&ctl,&output_ops) &&
      fg_heartbeat(&ctl,esp_timer_get_time(),gpio_get_level(FAULT)))
    gpio_set_level(HB,ctl.hb);
  }else {gpio_set_level(ARM,0);if(available&&ctl.state==FG_FAULT){uint8_t p[4];fg_ports(&ctl,p);(void)apply(p);}}
  /* Only log a new transition, never write flash continuously while faulted. */
  if(ctl.state==FG_FAULT&&!previous_fault)record_fault_once(now,previous_state);
  previous_fault=(ctl.state==FG_FAULT);previous_state=ctl.state;
  unsigned gears=0;for(unsigned i=0;i<7;i++)if(ctl.phase[i])gears|=1u<<i;
  atomic_store(&motor_mask,gears);atomic_store(&light_mask,(ctl.led[0]?1u:0u)|(ctl.led[1]?2u:0u));
  atomic_store(&shown_fault,fault_number(ctl.fault));atomic_store(&shown_state,ctl.state);vTaskDelayUntil(&tick,pdMS_TO_TICKS(5));
 }
}
static void draw_clock(lv_timer_t *timer){
 (void)timer;static const char *names[]={"BOOT / OFF","OFF","START CHECK","RUN","FAULT / OFF"};
 int state=atomic_load(&shown_state);lv_label_set_text(state_label,names[state]);
 if(atomic_load(&status_page)){
  static const char *faults[]={"none","physical input","I2C init","startup health","readback mismatch","phase deadline","multiple phase","unknown"};
  unsigned gears=atomic_load(&motor_mask),lights=atomic_load(&light_mask);int f=atomic_load(&shown_fault);if(f<0||f>7)f=7;
  for(unsigned i=0;i<3;i++)lv_obj_add_flag(hands[i],LV_OBJ_FLAG_HIDDEN);
  lv_obj_add_flag(state_label,LV_OBJ_FLAG_HIDDEN);lv_obj_remove_flag(status_label,LV_OBJ_FLAG_HIDDEN);
  if(atomic_load(&clock_valid)){struct timeval tv;gettimeofday(&tv,0);fg_local_date t;
   if(display_timezone_valid&&fg_tzif_local(&display_timezone,(int64_t)tv.tv_sec,&t))
    lv_label_set_text_fmt(clock_label,"%02d:%02d:%02d JST",t.hour,t.minute,t.second);
   else lv_label_set_text(clock_label,"TIMEZONE UNSET");}
  else lv_label_set_text(clock_label,"TIME UNSET");
  lv_label_set_text_fmt(status_label,
   "CTRL   %s\nGEARS  1:%s 2:%s 3:%s 4:%s\n       5:%s 6:%s 7:%s\nLIGHTS  L:%s  R:%s\nCLOCK   %s\nNETWORK disabled in review build\nFAULT   %s\nPAIRING AP service not implemented%s",
   names[state],
   gears&1?"ON":"OFF",gears&2?"ON":"OFF",gears&4?"ON":"OFF",gears&8?"ON":"OFF",gears&16?"ON":"OFF",gears&32?"ON":"OFF",gears&64?"ON":"OFF",
   lights&1?"ON":"OFF",lights&2?"ON":"OFF",atomic_load(&clock_valid)?"RTC holdover":"unset",faults[f],atomic_load(&pairing_requested)?" (request recorded)":"");
  return;
 }
 lv_obj_add_flag(status_label,LV_OBJ_FLAG_HIDDEN);lv_obj_remove_flag(state_label,LV_OBJ_FLAG_HIDDEN);lv_obj_remove_flag(clock_label,LV_OBJ_FLAG_HIDDEN);
 if(!atomic_load(&clock_valid)){lv_label_set_text(clock_label,"TIME UNSET");for(unsigned i=0;i<3;i++)lv_obj_add_flag(hands[i],LV_OBJ_FLAG_HIDDEN);return;}
 struct timeval tv;gettimeofday(&tv,0);fg_local_date t;
 if(!display_timezone_valid||!fg_tzif_local(&display_timezone,(int64_t)tv.tv_sec,&t)){
  lv_label_set_text(clock_label,"TIMEZONE UNSET");
  for(unsigned i=0;i<3;i++)lv_obj_add_flag(hands[i],LV_OBJ_FLAG_HIDDEN);
  return;
 }
 double sec=t.second+tv.tv_usec/1000000.0;double angles[3]={((t.hour%12)+t.minute/60.0+sec/3600.0)*M_PI/6,(t.minute+sec/60.0)*M_PI/30,sec*M_PI/30};
 static const int lengths[3]={170,245,280};
 for(unsigned i=0;i<3;i++){hand_points[i][0]=(lv_point_precise_t){400,400};hand_points[i][1]=(lv_point_precise_t){400+sin(angles[i])*lengths[i],400-cos(angles[i])*lengths[i]};lv_line_set_points(hands[i],hand_points[i],2);lv_obj_remove_flag(hands[i],LV_OBJ_FLAG_HIDDEN);}
 lv_label_set_text_fmt(clock_label,"%02d:%02d:%02d",t.hour,t.minute,t.second);
}
void app_main(void){
 fg_init(&ctl);fg_clock_init(&utc_clock);
 display_timezone_valid=fg_tzif_parse(&display_timezone,fg_default_tokyo_tzif,fg_default_tokyo_tzif_len);
 gpio_set_level(ARM,0);gpio_set_level(HB,0);
 gpio_config_t out={.pin_bit_mask=(1ULL<<ARM)|(1ULL<<HB),.mode=GPIO_MODE_OUTPUT,.pull_down_en=GPIO_PULLDOWN_ENABLE};ESP_ERROR_CHECK(gpio_config(&out));
 gpio_config_t in={.pin_bit_mask=(1ULL<<FAULT)|(1ULL<<SW1)|(1ULL<<SW2),.mode=GPIO_MODE_INPUT};ESP_ERROR_CHECK(gpio_config(&in));
 ESP_ERROR_CHECK(nvs_flash_init());
 intent_queue=xQueueCreate(8,sizeof(fg_intent));
 journal_queue=xQueueCreate(2,sizeof(fgp_fault_ring));
 if(!intent_queue||!journal_queue){gpio_set_level(ARM,0);abort();}
 (void)fg_journal_restore(&journal_io,&persisted_faults);
 if(xTaskCreate(journal_task,"fault_writer",4096,NULL,4,NULL)!=pdPASS){
  gpio_set_level(ARM,0);abort();
 }
 /* No network producer is registered until HTTPS/auth integration is validated. */
 if(xTaskCreatePinnedToCore(control_task,"mechanism",6144,0,12,0,1)!=pdPASS){gpio_set_level(ARM,0);abort();}
 if(!bsp_display_start()){ESP_LOGE(TAG,"Display initialization failed; controller stays independently serviced");return;}
 bsp_display_brightness_set(50);/* Peak1.5A module qualification still required. */
 if (!bsp_display_lock(0)) {
  ESP_LOGE(TAG,"LVGL mutex acquisition failed; refusing UI initialization");
  return;
 }
 lv_obj_t *screen=lv_screen_active();lv_obj_set_style_bg_color(screen,lv_color_black(),0);
 clock_label=lv_label_create(screen);lv_obj_set_style_text_color(clock_label,lv_color_white(),0);lv_obj_set_style_text_font(clock_label,&lv_font_montserrat_32,0);lv_obj_align(clock_label,LV_ALIGN_CENTER,0,170);
 state_label=lv_label_create(screen);lv_obj_set_style_text_color(state_label,lv_color_hex(0xa8a8a8),0);lv_obj_align(state_label,LV_ALIGN_CENTER,0,220);
 status_label=lv_label_create(screen);lv_obj_set_style_text_color(status_label,lv_color_white(),0);lv_obj_set_style_text_font(status_label,&lv_font_montserrat_32,0);lv_obj_set_style_text_align(status_label,LV_TEXT_ALIGN_LEFT,0);lv_obj_align(status_label,LV_ALIGN_CENTER,0,-20);lv_obj_add_flag(status_label,LV_OBJ_FLAG_HIDDEN);
 for(unsigned i=0;i<3;i++){hands[i]=lv_line_create(screen);lv_obj_set_style_line_width(hands[i],i==2?3:7,0);lv_obj_set_style_line_color(hands[i],lv_color_hex(i==2?0xe9973f:0xe9ddb6),0);lv_obj_set_style_line_rounded(hands[i],true,0);}
 lv_timer_create(draw_clock,33,0);bsp_display_unlock();
}
