#ifndef FG_BOARD_PINS_H
#define FG_BOARD_PINS_H
/* Forest Guardian Phase65: REVIEW PIN PLAN, NOT ELECTRICALLY QUALIFIED.
 * External MCP23017/RTC I2C, external power interlock and buttons.
 * GPIO20/22 MUST be checked against the actual XC schematic and C6 host link
 * before networking and motors can be qualified together. Do not infer from
 * similar (4B/DB) boards that the XC has the same pin connections.
 */
#define FG_PIN_ARM         GPIO_NUM_32
#define FG_PIN_HEARTBEAT   GPIO_NUM_28
#define FG_PIN_FAULT       GPIO_NUM_22
#define FG_PIN_SW1         GPIO_NUM_29
#define FG_PIN_SW2         GPIO_NUM_30
#define FG_PIN_MCP_SDA     GPIO_NUM_20
#define FG_PIN_MCP_SCL     GPIO_NUM_21
#endif
