#include "fg_clock.h"
#include <limits.h>
#include <string.h>
/* Restrict accepted samples to RX8900's intended application period. */
#define UTC_MIN 946684800LL /* 2000-01-01 */
#define UTC_MAX 4102444799LL /* 2099-12-31 */
void fg_clock_init(fg_clock *c){if(c)memset(c,0,sizeof(*c));}
bool fg_clock_set_rtc(fg_clock *c,fg_utc_time rtc,uint64_t tick){
 int64_t sec;
 if(!c||!fg_time_unix_utc(rtc,&sec)||sec<UTC_MIN||sec>UTC_MAX)return false;
 /* Once network-synchronized, an RTC sample cannot override better time. */
 if(c->ever_sntp|| (c->valid&&tick<c->monotonic_ms))return false;
 c->utc_sec=sec;c->monotonic_ms=tick;c->valid=true;return true;
}
bool fg_clock_set_sntp(fg_clock *c,int64_t sec,uint64_t tick){
 if(!c||sec<UTC_MIN||sec>UTC_MAX|| (c->valid&&tick<c->monotonic_ms))return false;
 /* A network correction is intentionally allowed to move civil time backward. */
 c->utc_sec=sec;c->monotonic_ms=tick;c->last_sntp_ms=tick;
 c->ever_sntp=true;c->valid=true;return true;
}
bool fg_clock_now(const fg_clock *c,uint64_t tick,int64_t *sec,unsigned *ms,fg_time_quality *q){
 if(!c||!c->valid||tick<c->monotonic_ms||!sec||!ms||!q)return false;
 uint64_t delta=tick-c->monotonic_ms;
 if(delta/1000ULL>(uint64_t)(UTC_MAX-c->utc_sec))return false;
 *sec=c->utc_sec+(int64_t)(delta/1000ULL);*ms=(unsigned)(delta%1000ULL);
 *q=!c->ever_sntp?FG_TIME_RTC:
     ((tick-c->last_sntp_ms)<FG_SNTP_INTERVAL_MS?FG_TIME_SNTP:FG_TIME_HOLDOVER);
 return true;
}
bool fg_clock_sync_due(const fg_clock *c,uint64_t tick){
 if(!c||!c->valid)return true;
 if(tick<c->monotonic_ms|| (c->ever_sntp&&tick<c->last_sntp_ms))return true;
 uint64_t since=c->ever_sntp?tick-c->last_sntp_ms:tick-c->monotonic_ms;
 return since>=FG_SNTP_INTERVAL_MS;
}
