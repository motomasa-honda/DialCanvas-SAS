#ifndef FG_CLOCK_H
#define FG_CLOCK_H
#include <stdbool.h>
#include <stdint.h>
#include "fg_time.h"
/* Pure UTC clock. No GPIO, motor, flash, RTC writes, sockets, or malloc. */
#define FG_SNTP_INTERVAL_MS (6ULL * 60ULL * 60ULL * 1000ULL)
typedef enum {FG_TIME_UNSET=0, FG_TIME_RTC, FG_TIME_SNTP, FG_TIME_HOLDOVER} fg_time_quality;
typedef struct {
 int64_t utc_sec;
 uint64_t monotonic_ms;
 uint64_t last_sntp_ms;
 bool valid, ever_sntp;
} fg_clock;
void fg_clock_init(fg_clock *c);
bool fg_clock_set_rtc(fg_clock *c, fg_utc_time rtc, uint64_t monotonic_ms);
bool fg_clock_set_sntp(fg_clock *c, int64_t network_utc_sec, uint64_t monotonic_ms);
bool fg_clock_now(const fg_clock *c, uint64_t monotonic_ms, int64_t *utc_sec, unsigned *ms,
                  fg_time_quality *quality);
bool fg_clock_sync_due(const fg_clock *c, uint64_t monotonic_ms);
#endif
