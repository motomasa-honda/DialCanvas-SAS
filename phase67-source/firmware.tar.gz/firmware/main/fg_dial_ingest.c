#include "fg_dial_ingest.h"
#include "fg_zip_gate.h"
fg_dial_result fg_dial_install_guarded(const fg_dial_io *io,
 const uint8_t *archive,size_t len,uint32_t budget,fg_dial_record *installed){
 if(!io||!archive||!installed)return FG_DIAL_INVALID_IO;
 if(fg_zip_gate(archive,len)!=FG_ZIP_OK)return FG_DIAL_REJECT;
 return fg_dial_install(io,archive,len,budget,installed);
}
