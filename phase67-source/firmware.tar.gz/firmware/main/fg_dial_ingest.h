#ifndef FG_DIAL_INGEST_H
#define FG_DIAL_INGEST_H
#include "fg_dial_store.h"
/* PRECONDITION: validate_input callback MUST perform full semantic ZIP/PNG/
   manifest/SHA-256 checks with real cryptographic hash. This wrapper adds
   structural ZIP admission only, not an authenticated upload endpoint. */
fg_dial_result fg_dial_install_guarded(const fg_dial_io *io,
 const uint8_t *archive,size_t len,uint32_t budget,fg_dial_record *installed);
#endif
