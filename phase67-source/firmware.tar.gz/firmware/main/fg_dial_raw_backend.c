/* ESP-IDF raw A/B dial slot adapter. Phase62 REVIEW; NOT a shipping backend.
 * Platform flash/NVS atomics, encryption alignment and watchdog recovery MUST
 * pass ESP32-P4 tests before production. Keep all I/O off the 5ms control task.
 */
#include "fg_dial_raw_backend.h"
#include <string.h>
#include "esp_err.h"
#include "nvs.h"
#include "mbedtls/sha256.h"

#define FG_ERASE_SECTOR 4096u
#define FG_IO_CHUNK 1024u

static bool good_slot(fg_dial_raw_context *ctx, unsigned slot) {
    return ctx && slot < 2u && ctx->slots[slot] &&
           ctx->slots[slot]->size >= FG_DIAL_PACKAGE_LIMIT &&
           (ctx->slots[slot]->size % FG_ERASE_SECTOR) == 0u;
}
static bool read_record(void *context, unsigned index, fg_dial_record *out) {
    fg_dial_raw_context *ctx = (fg_dial_raw_context *)context;
    if (!ctx || !out || index > 1u || ctx->metadata_io_failed) return false;
    nvs_handle_t nvs;
    esp_err_t err = nvs_open("fg_dials", NVS_READONLY, &nvs);
    /* On first boot the namespace may not exist; that is different from an
     * NVS I/O failure.  Only a verified NOT_FOUND means an absent pointer. */
    if (err == ESP_ERR_NVS_NOT_FOUND) return false;
    if (err != ESP_OK) { ctx->metadata_io_failed = true; return false; }
    size_t len = sizeof(*out);
    err = nvs_get_blob(nvs, index ? "ptr1" : "ptr0", out, &len);
    nvs_close(nvs);
    if (err == ESP_ERR_NVS_NOT_FOUND) return false;
    if (err != ESP_OK || len != sizeof(*out)) {
        ctx->metadata_io_failed = true;
        return false;
    }
    return true;
}
static bool write_record(void *context, unsigned index, const fg_dial_record *rec) {
    fg_dial_raw_context *ctx = (fg_dial_raw_context *)context;
    if (!ctx || ctx->metadata_io_failed || !rec || index > 1u) return false;
    nvs_handle_t nvs;
    if (nvs_open("fg_dials", NVS_READWRITE, &nvs) != ESP_OK) return false;
    esp_err_t err = nvs_set_blob(nvs, index ? "ptr1" : "ptr0", rec, sizeof(*rec));
    if (err == ESP_OK) err = nvs_commit(nvs);
    nvs_close(nvs);
    return err == ESP_OK;
}
static bool capacity(void *context, unsigned slot, uint32_t *bytes) {
    fg_dial_raw_context *ctx = (fg_dial_raw_context *)context;
    if (!bytes || !good_slot(ctx, slot) || ctx->metadata_io_failed) return false;
    /* Direct raw flash: payload has no filesystem allocation overhead. */
    *bytes = ctx->slots[slot]->size;
    return true;
}
static bool write_slot(void *context, unsigned slot, const uint8_t *data, size_t size) {
    fg_dial_raw_context *ctx = (fg_dial_raw_context *)context;
    if (!good_slot(ctx, slot) || ctx->metadata_io_failed || !data || !size ||
        size > FG_DIAL_PACKAGE_LIMIT || size > ctx->slots[slot]->size) return false;
    const esp_partition_t *part = ctx->slots[slot];
    /* Erase only destination slot; never touch currently active slot. Erasing
       only rounded-up used sectors avoids unnecessary flash wear. */
    size_t erase_bytes = ((size + FG_ERASE_SECTOR - 1u) / FG_ERASE_SECTOR) * FG_ERASE_SECTOR;
    for (size_t at = 0; at < erase_bytes; at += FG_ERASE_SECTOR)
        if (esp_partition_erase_range(part, at, FG_ERASE_SECTOR) != ESP_OK) return false;
    uint8_t padded[FG_IO_CHUNK];
    for (size_t at = 0; at < size; at += FG_IO_CHUNK) {
        size_t len = size - at < FG_IO_CHUNK ? size - at : FG_IO_CHUNK;
        /* Last write rounded to 16 bytes for encrypted ESP flash operation.
           Digest/record still cover only the exact archive bytes. */
        size_t physical_len = (len + 15u) & ~(size_t)15u;
        memset(padded, 0xff, sizeof(padded));
        memcpy(padded, data + at, len);
        if (esp_partition_write(part, at, padded, physical_len) != ESP_OK) return false;
    }
    return true;
}
static bool verify_slot(void *context, unsigned slot, uint32_t size, const uint8_t digest[32]) {
    fg_dial_raw_context *ctx = (fg_dial_raw_context *)context;
    if (!digest || !good_slot(ctx, slot) || !size ||
        size > FG_DIAL_PACKAGE_LIMIT || size > ctx->slots[slot]->size) return false;
    uint8_t buf[FG_IO_CHUNK], actual[32];
    mbedtls_sha256_context hash;
    mbedtls_sha256_init(&hash);
    bool ok = mbedtls_sha256_starts(&hash, 0) == 0;
    for (size_t at = 0; ok && at < size; at += FG_IO_CHUNK) {
        size_t len = size - at < FG_IO_CHUNK ? size - at : FG_IO_CHUNK;
        ok = esp_partition_read(ctx->slots[slot], at, buf, len) == ESP_OK &&
             mbedtls_sha256_update(&hash, buf, len) == 0;
    }
    if (ok) ok = mbedtls_sha256_finish(&hash, actual) == 0 &&
                  memcmp(actual, digest, 32) == 0;
    mbedtls_sha256_free(&hash);
    return ok;
}
static bool validate(void *context, const uint8_t *data, size_t size, uint8_t digest[32]) {
    fg_dial_raw_context *ctx = (fg_dial_raw_context *)context;
    return ctx && ctx->validate && ctx->validate(ctx->validate_context, data, size, digest);
}
bool fg_dial_raw_init(fg_dial_raw_context *ctx,
                      fg_dial_semantic_validator validator, void *validator_context) {
    if (!ctx || !validator) return false;
    memset(ctx, 0, sizeof(*ctx));
    ctx->slots[0] = esp_partition_find_first(ESP_PARTITION_TYPE_DATA,
                    ESP_PARTITION_SUBTYPE_ANY, "dial_slot_a");
    ctx->slots[1] = esp_partition_find_first(ESP_PARTITION_TYPE_DATA,
                    ESP_PARTITION_SUBTYPE_ANY, "dial_slot_b");
    ctx->validate = validator;
    ctx->validate_context = validator_context;
    if (!good_slot(ctx, 0u) || !good_slot(ctx, 1u) ||
        ctx->slots[0] == ctx->slots[1]) return false;
    uint64_t a0 = ctx->slots[0]->address;
    uint64_t a1 = ctx->slots[1]->address;
    uint64_t b0 = a0 + ctx->slots[0]->size;
    uint64_t b1 = a1 + ctx->slots[1]->size;
    return b0 <= a1 || b1 <= a0;
}
void fg_dial_raw_bind(fg_dial_raw_context *ctx, fg_dial_io *io) {
    if (!io) return;
    memset(io, 0, sizeof(*io));
    if (!good_slot(ctx, 0u) || !good_slot(ctx, 1u) || !ctx->validate) return;
    io->ctx = ctx;
    io->read_record = read_record;
    io->write_record = write_record;
    io->slot_capacity = capacity;
    io->write_slot = write_slot;
    io->verify_slot = verify_slot;
    io->validate_input = validate;
}

uint32_t fg_dial_raw_budget(const fg_dial_raw_context *ctx) {
    if (!ctx || !ctx->slots[0] || !ctx->slots[1]) return 0;
    /* Nominal 2 x 10 MiB + 1 MiB separate reserve; checked by partition audit. */
    if (ctx->slots[0]->size < FG_DIAL_PACKAGE_LIMIT ||
        ctx->slots[1]->size < FG_DIAL_PACKAGE_LIMIT) return 0;
    return 2u * FG_DIAL_PACKAGE_LIMIT + FG_DIAL_RESERVED_BYTES;
}
