#ifndef FG_DIAL_RAW_BACKEND_H
#define FG_DIAL_RAW_BACKEND_H
/* Phase62 EXPERIMENTAL: not connected to product update endpoint.
 * Never call this backend on 5ms motor-control task.  Fail closed without
 * a FULL semantic ZIP/PNG/JSON/SHA256 validator. */
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#include "esp_partition.h"
#include "fg_dial_store.h"

typedef bool (*fg_dial_semantic_validator)(void *context, const uint8_t *data,
                                           size_t len, uint8_t digest[32]);
typedef struct {
    const esp_partition_t *slots[2];
    fg_dial_semantic_validator validate;
    void *validate_context;
    /* Latches unexpected NVS read failures; must reinitialize after repair. */
    bool metadata_io_failed;
} fg_dial_raw_context;

/* Called after nvs_flash_init() in a dedicated updater task, not at boot
 * by the control task. Partition labels must match the REVIEW layout. */
bool fg_dial_raw_init(fg_dial_raw_context *ctx,
                      fg_dial_semantic_validator validate,
                      void *validate_context);
void fg_dial_raw_bind(fg_dial_raw_context *ctx, fg_dial_io *io);
/* Logical quota includes 1MiB dedicated flash reserve (not part of user slots). */
uint32_t fg_dial_raw_budget(const fg_dial_raw_context *ctx);
#endif
