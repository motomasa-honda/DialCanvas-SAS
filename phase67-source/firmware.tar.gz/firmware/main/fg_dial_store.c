#include "fg_dial_store.h"
#include <limits.h>
#include <string.h>

static uint32_t crc_byte(uint32_t crc,uint8_t b){
 crc^=b;
 for(unsigned bit=0;bit<8;bit++)crc=(crc>>1)^((crc&1u)?0xedb88320u:0u);
 return crc;
}
static uint32_t crc_u64(uint32_t crc,uint64_t number,unsigned count){
 for(unsigned i=0;i<count;i++)crc=crc_byte(crc,(uint8_t)(number>>(8u*i)));
 return crc;
}
uint32_t fg_dial_record_crc(const fg_dial_record *r){
 if(!r)return 0;
 uint32_t crc=0xffffffffu;
 crc=crc_u64(crc,r->magic,4);crc=crc_u64(crc,r->version,4);
 crc=crc_u64(crc,r->generation,8);crc=crc_u64(crc,r->size_bytes,4);
 crc=crc_byte(crc,r->slot);
 for(unsigned i=0;i<32;i++)crc=crc_byte(crc,r->sha256[i]);
 return crc^0xffffffffu;
}
static bool valid_io(const fg_dial_io *io){
 return io && io->read_record && io->verify_slot;
}
static bool record_ok(const fg_dial_io *io,unsigned index,fg_dial_record *out){
 fg_dial_record r;
 memset(&r,0,sizeof(r));
 if(!io->read_record(io->ctx,index,&r)||r.magic!=FG_DIAL_MAGIC||
    r.version!=FG_DIAL_VERSION||r.generation==0||
    r.generation==UINT64_MAX||r.slot>1||
    r.size_bytes==0||r.size_bytes>FG_DIAL_PACKAGE_LIMIT||
    fg_dial_record_crc(&r)!=r.crc32||
    !io->verify_slot(io->ctx,r.slot,r.size_bytes,r.sha256))return false;
 *out=r;return true;
}
bool fg_dial_active(const fg_dial_io *io,fg_dial_record *out){
 if(!valid_io(io)||!out)return false;
 fg_dial_record a,b;
 bool va=record_ok(io,0,&a),vb=record_ok(io,1,&b);
 if(!va&&!vb)return false;
 /* Generation ties to different slots/digests are ambiguous; fail closed. */
 if(va&&vb&&a.generation==b.generation &&
    (a.slot!=b.slot||a.size_bytes!=b.size_bytes||
     memcmp(a.sha256,b.sha256,32)!=0))return false;
 *out=(!va||(vb&&b.generation>a.generation))?b:a;
 return true;
}
fg_dial_result fg_dial_install(const fg_dial_io *io,const uint8_t *candidate,
 size_t size,uint32_t budget_bytes,fg_dial_record *installed){
 if(!valid_io(io)||!io->write_record||!io->write_slot||!io->slot_capacity||!io->validate_input||
    !candidate||!installed)return FG_DIAL_INVALID_IO;
 if(size==0||size>FG_DIAL_PACKAGE_LIMIT||size>UINT32_MAX)return FG_DIAL_REJECT;
 if(budget_bytes<=FG_DIAL_RESERVED_BYTES)return FG_DIAL_NO_SPACE;
 uint8_t digest[32];
 if(!io->validate_input(io->ctx,candidate,size,digest))return FG_DIAL_REJECT;
 fg_dial_record active;
 bool has_active=fg_dial_active(io,&active);
 /* If no pointer verifies, ANY readable metadata is evidence that the store
  * has already been initialized.  Corrupted magic or a partially committed
  * record must never silently authorize an overwrite of a recoverable slot.
  * First-boot initialization is allowed only when BOTH records are absent.
  * Explicit factory-reset/reprovision is a separate service operation. */
 fg_dial_record raw;
 if(!has_active){
  for(unsigned i=0;i<2;i++){
   if(io->read_record(io->ctx,i,&raw))return FG_DIAL_VERIFY_FAILED;
  }
 }
 uint64_t used=has_active?(uint64_t)active.size_bytes:0;
 if(used+(uint64_t)size+FG_DIAL_RESERVED_BYTES>budget_bytes)return FG_DIAL_NO_SPACE;
 if(has_active&&active.generation>=UINT64_MAX-2u)return FG_DIAL_GEN_EXHAUSTED;
 unsigned target_slot=has_active?(unsigned)(1u-active.slot):0u;
 uint32_t usable_target=0;
 if(!io->slot_capacity(io->ctx,target_slot,&usable_target))return FG_DIAL_INVALID_IO;
 if((uint64_t)size>usable_target)return FG_DIAL_NO_SPACE;
 /* Abort before modifying flash if active physical slot capacity no longer
  * matches an existing verified package (filesystem/partition drift). */
 if(has_active){
  uint32_t usable_active=0;
  if(!io->slot_capacity(io->ctx,active.slot,&usable_active))return FG_DIAL_INVALID_IO;
  if(active.size_bytes>usable_active)return FG_DIAL_VERIFY_FAILED;
 }
 if(!io->write_slot(io->ctx,target_slot,candidate,size))return FG_DIAL_WRITE_FAILED;
 if(!io->verify_slot(io->ctx,target_slot,(uint32_t)size,digest))return FG_DIAL_VERIFY_FAILED;
 fg_dial_record next;
 memset(&next,0,sizeof(next));
 next.magic=FG_DIAL_MAGIC;next.version=FG_DIAL_VERSION;
 next.generation=has_active?active.generation+1u:1u;
 next.size_bytes=(uint32_t)size;next.slot=(uint8_t)target_slot;
 memcpy(next.sha256,digest,sizeof(digest));
 next.crc32=fg_dial_record_crc(&next);
 /* Only one durable pointer is modified, always after fully verified write. */
 if(!io->write_record(io->ctx,(unsigned)(next.generation&1u),&next))
  return FG_DIAL_WRITE_FAILED;
 fg_dial_record observed;
 if(!fg_dial_active(io,&observed)||observed.generation!=next.generation||
    observed.slot!=next.slot||memcmp(observed.sha256,next.sha256,32)!=0)
  return FG_DIAL_VERIFY_FAILED;
 *installed=observed;
 return FG_DIAL_OK;
}
