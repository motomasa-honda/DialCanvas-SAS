#ifndef FG_DIAL_STORE_H
#define FG_DIAL_STORE_H
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
/* SW-11 port layer: bounded state/metadata only. No ZIP/PNG decoder or flash driver.
 * Every callback must run outside the 5ms motor-control task.
 * write_record MUST be durable and atomic (old OR new record after power loss).
 * write_slot MUST preserve the other slot; verify_slot rechecks actual persisted bytes.
 */
#define FG_DIAL_PACKAGE_LIMIT (10u*1024u*1024u)
#define FG_DIAL_STORE_BUDGET (16u*1024u*1024u)
#define FG_DIAL_RESERVED_BYTES (1u*1024u*1024u)
#define FG_DIAL_MAGIC 0x4647444cu
#define FG_DIAL_VERSION 1u

typedef struct {
 uint32_t magic;
 uint32_t version;
 uint64_t generation;
 uint32_t size_bytes;
 uint8_t slot;
 uint8_t sha256[32];
 uint32_t crc32;
} fg_dial_record;

typedef struct {
 void *ctx;
 bool (*read_record)(void *ctx,unsigned index,fg_dial_record *out);
 bool (*write_record)(void *ctx,unsigned index,const fg_dial_record *record);
 bool (*verify_slot)(void *ctx,unsigned slot,uint32_t size,const uint8_t sha256[32]);
 bool (*write_slot)(void *ctx,unsigned slot,const uint8_t *data,size_t len);
 /* REQUIRED: independently measured/allocated usable payload capacity for
  * each physical slot, excluding filesystem overhead. Total quota alone does
  * NOT establish that a candidate fits in its destination slot. */
 bool (*slot_capacity)(void *ctx,unsigned slot,uint32_t *usable_bytes);
 /* MUST validate ZIP/manifest/PNG exhaustively and compute real SHA-256.
  * A digest match by itself does NOT authenticate a dial package. */
 bool (*validate_input)(void *ctx,const uint8_t *data,size_t len,uint8_t sha256[32]);
} fg_dial_io;

typedef enum {
 FG_DIAL_OK=0, FG_DIAL_REJECT, FG_DIAL_NO_SPACE,
 FG_DIAL_INVALID_IO, FG_DIAL_WRITE_FAILED, FG_DIAL_VERIFY_FAILED,
 FG_DIAL_GEN_EXHAUSTED
} fg_dial_result;

uint32_t fg_dial_record_crc(const fg_dial_record *record);
bool fg_dial_active(const fg_dial_io *io,fg_dial_record *out);
fg_dial_result fg_dial_install(const fg_dial_io *io,const uint8_t *candidate,
 size_t size,uint32_t budget_bytes,fg_dial_record *installed);
#endif
