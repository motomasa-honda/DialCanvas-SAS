#include "fg_journal.h"
#include <limits.h>
#include <string.h>
#define RECORD_OFF 28U
static void put16(uint8_t *p,uint16_t v){p[0]=(uint8_t)v;p[1]=(uint8_t)(v>>8);}
static void put32(uint8_t *p,uint32_t v){for(unsigned i=0;i<4;i++)p[i]=(uint8_t)(v>>(8*i));}
static void put64(uint8_t *p,uint64_t v){for(unsigned i=0;i<8;i++)p[i]=(uint8_t)(v>>(8*i));}
static uint16_t get16(const uint8_t *p){return (uint16_t)(p[0]|((uint16_t)p[1]<<8));}
static uint32_t get32(const uint8_t *p){uint32_t v=0;for(unsigned i=0;i<4;i++)v|=(uint32_t)p[i]<<(8*i);return v;}
static uint64_t get64(const uint8_t *p){uint64_t v=0;for(unsigned i=0;i<8;i++)v|=(uint64_t)p[i]<<(8*i);return v;}
static uint32_t crc32_without_checksum(const uint8_t *b){
 uint32_t crc=UINT32_MAX;
 for(unsigned i=0;i<FG_JOURNAL_SLOT_SIZE;i++){
  if(i>=24&&i<28)continue;
  crc^=b[i];for(unsigned j=0;j<8;j++)crc=(crc>>1)^(0xEDB88320U & (0U-(crc&1U)));
 }
 return ~crc;
}
static void encode(uint8_t *b,const fgp_fault_ring *h,uint64_t gen){
 memset(b,0,FG_JOURNAL_SLOT_SIZE);memcpy(b,"FGJR",4);
 put16(b+4,1);put16(b+6,(uint16_t)FG_JOURNAL_SLOT_SIZE);put64(b+8,gen);
 put32(b+16,h->next);put32(b+20,h->count);
 for(unsigned i=0;i<FG_FAULT_CAPACITY;i++){
  const fgp_fault_event *e=&h->item[i];uint8_t *p=b+RECORD_OFF+i*24U;
  put64(p,e->monotonic_ms);put64(p+8,(uint64_t)e->utc_seconds);
  put32(p+16,e->fault_code);p[20]=e->hw_power_good;p[21]=e->hw_fault;p[22]=e->prior_state;
 }
 put32(b+24,crc32_without_checksum(b));
}
static bool decode(const uint8_t *b,fgp_fault_ring *h,uint64_t *gen){
 if(memcmp(b,"FGJR",4)!=0||get16(b+4)!=1||get16(b+6)!=FG_JOURNAL_SLOT_SIZE)return false;
 if(get32(b+24)!=crc32_without_checksum(b))return false;
 uint32_t next=get32(b+16),count=get32(b+20);
 if(next>=FG_FAULT_CAPACITY||count>FG_FAULT_CAPACITY)return false;
 memset(h,0,sizeof(*h));h->next=next;h->count=count;*gen=get64(b+8);
 for(unsigned i=0;i<FG_FAULT_CAPACITY;i++){
  const uint8_t *p=b+RECORD_OFF+i*24U;fgp_fault_event *e=&h->item[i];
  e->monotonic_ms=get64(p);e->utc_seconds=(int64_t)get64(p+8);
  e->fault_code=get32(p+16);e->hw_power_good=p[20];e->hw_fault=p[21];e->prior_state=p[22];
 }
 /* A reboot never restores an active motor/fault state from NVS. */
 h->open_fault=false;h->open_fault_code=0;return true;
}
static int latest(const fg_journal_io *io,fgp_fault_ring *best,uint64_t *gen){
 if(!io||!io->read)return -1;
 int chosen=-1;uint64_t highest=0;
 for(unsigned slot=0;slot<2;slot++){
  uint8_t buf[FG_JOURNAL_SLOT_SIZE];fgp_fault_ring temp;uint64_t candidate;
  if(!io->read(io->context,slot,buf,sizeof(buf))||!decode(buf,&temp,&candidate))continue;
  if(chosen<0||candidate>highest){chosen=(int)slot;highest=candidate;if(best)*best=temp;}
 }
 if(chosen>=0&&gen)*gen=highest;
 return chosen;
}
bool fg_journal_restore(const fg_journal_io *io,fgp_fault_ring *history){
 if(!history)return false;
 memset(history,0,sizeof(*history));
 return latest(io,history,0)>=0;
}
bool fg_journal_commit(const fg_journal_io *io,const fgp_fault_ring *history){
 if(!io||!io->read||!io->write||!history||history->next>=FG_FAULT_CAPACITY||history->count>FG_FAULT_CAPACITY)return false;
 uint64_t gen=0;int curr=latest(io,0,&gen);
 if(curr>=0&&gen==UINT64_MAX)return false;
 uint8_t buffer[FG_JOURNAL_SLOT_SIZE];encode(buffer,history,curr<0?1:gen+1);
 return io->write(io->context,curr<0?0:(unsigned)(1-curr),buffer,sizeof(buffer));
}
