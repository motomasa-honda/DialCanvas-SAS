#ifndef FG_JOURNAL_H
#define FG_JOURNAL_H
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#include "fg_policy.h"
#define FG_JOURNAL_SLOT_SIZE (28U+FG_FAULT_CAPACITY*24U)
typedef struct {
 void *context;
 /* Read full slot 0 or 1; false if unprogrammed or I/O error. */
 bool (*read)(void *context,unsigned slot,uint8_t *out,size_t length);
 /* Replace one entire slot; must complete/durably commit before reporting true. */
 bool (*write)(void *context,unsigned slot,const uint8_t *data,size_t length);
} fg_journal_io;
/* Loading invalid/corrupt slots yields an empty ring and false. */
bool fg_journal_restore(const fg_journal_io *io,fgp_fault_ring *history);
/* Commit to the older slot; a failed/torn write leaves prior valid snapshot recoverable.
   Called only on fault ring changes, never every controller tick. */
bool fg_journal_commit(const fg_journal_io *io,const fgp_fault_ring *history);
#endif
