#ifndef FG_POLICY_H
#define FG_POLICY_H
#include <stdbool.h>
#include <stdint.h>
#define FG_FAULT_CAPACITY 64
#define FG_PAIR_WINDOW_MS 600000ULL
#define FG_SESSION_IDLE_MS 1800000ULL
#define FG_MAX_SESSIONS 2
typedef enum {FGP_BOOT=0,FGP_OFF,FGP_STARTING,FGP_RUNNING,FGP_FAULT,FGP_UPDATING} fgp_state;
typedef enum {FGP_DENY=0,FGP_ALLOW=1} fgp_result;
typedef struct {uint64_t monotonic_ms;int64_t utc_seconds;uint32_t fault_code;uint8_t hw_power_good,hw_fault,prior_state; } fgp_fault_event;
typedef struct {fgp_fault_event item[FG_FAULT_CAPACITY];uint32_t next,count;bool open_fault;uint32_t open_fault_code;} fgp_fault_ring;
typedef struct {
 fgp_state state;uint64_t last_start_sequence;
 bool fault_latched,hw_power_good,hw_fault_pin_ok,expander_readback_ok;
 bool pairing_open;uint64_t pairing_started_ms;
 bool ota_in_progress;bool ota_trial_pending;
 fgp_fault_ring history;
} fgp_policy;
void fgp_init(fgp_policy *p);
void fgp_set_health(fgp_policy *p,bool power_good,bool fault_pin_ok,bool expander_readback_ok);
fgp_result fgp_boot_complete(fgp_policy *p);
fgp_result fgp_start(fgp_policy *p,uint64_t sequence,bool authenticated,bool explicit_request);
void fgp_stop(fgp_policy *p);
void fgp_fault(fgp_policy *p,uint32_t code,uint64_t monotonic_ms,int64_t utc_seconds);
fgp_result fgp_clear_fault(fgp_policy *p,bool explicit_request,bool authenticated);
fgp_result fgp_pairing_request(fgp_policy *p,uint64_t now_ms,bool physical_chord_confirmed);
bool fgp_pairing_active(fgp_policy *p,uint64_t now_ms);
void fgp_pairing_finish(fgp_policy *p);
fgp_result fgp_ota_begin(fgp_policy *p,bool authenticated,bool image_preflight_verified);
void fgp_ota_abort(fgp_policy *p);
void fgp_ota_new_boot(fgp_policy *p);
fgp_result fgp_ota_mark_valid(fgp_policy *p,bool all_self_tests_ok,uint64_t stable_ms);
uint32_t fgp_fault_count(const fgp_policy *p);
#endif
