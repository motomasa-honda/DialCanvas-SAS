#include "fg_time.h"
static bool leap(int y){return y%4==0 && (y%100!=0 || y%400==0);}
bool fg_time_validate(fg_utc_time t){
 static const int md[]={31,28,31,30,31,30,31,31,30,31,30,31};
 if(t.year<2000||t.year>2099||t.month<1||t.month>12||t.hour<0||t.hour>23||t.minute<0||t.minute>59||t.second<0||t.second>59)return false;
 int days=md[t.month-1]+(t.month==2&&leap(t.year));return t.day>=1&&t.day<=days;
}
static int64_t days_civil(int y,unsigned m,unsigned d){
 y-=m<=2;int era=(y>=0?y:y-399)/400;unsigned yo=(unsigned)(y-era*400);
 int adjusted=(int)m+(m>2?-3:9);
 unsigned doy=(153*(unsigned)adjusted+2)/5+d-1;
 unsigned doe=yo*365+yo/4-yo/100+doy;return (int64_t)era*146097+(int64_t)doe-719468;
}
bool fg_time_unix_utc(fg_utc_time t,int64_t *out){
 if(!out||!fg_time_validate(t))return false;
 *out=days_civil(t.year,(unsigned)t.month,(unsigned)t.day)*86400+(int64_t)t.hour*3600+t.minute*60+t.second;return true;
}
static int bcd(uint8_t u){return (u>>4)*10+(u&15);}
static bool valid_bcd(uint8_t u){return (u&15)<=9 && (u>>4)<=9;}
bool fg_time_decode_rx8900(const uint8_t r[7],uint8_t flag,fg_utc_time *out){
 if(!r||!out||(flag&2))return false;
 uint8_t ss=r[0]&0x7f,mm=r[1]&0x7f,hh=r[2]&0x3f,dd=r[4]&0x3f,mo=r[5]&0x1f,yy=r[6];
 if(!valid_bcd(ss)||!valid_bcd(mm)||!valid_bcd(hh)||!valid_bcd(dd)||!valid_bcd(mo)||!valid_bcd(yy))return false;
 fg_utc_time tmp={.year=2000+bcd(yy),.month=bcd(mo),.day=bcd(dd),.hour=bcd(hh),.minute=bcd(mm),.second=bcd(ss)};
 if(!fg_time_validate(tmp))return false;
 *out=tmp;return true;
}
