#ifndef FG_TIME_H
#define FG_TIME_H
#include <stdint.h>
#include <stdbool.h>
typedef struct {int year,month,day,hour,minute,second;} fg_utc_time;
bool fg_time_validate(fg_utc_time t);
bool fg_time_unix_utc(fg_utc_time t,int64_t *unix_seconds);
/* RX8900 7 registers starting at 0x10, and 0x1e flag register.
   Consistent with existing D7 mapping; hardware register interpretation requires device-level review. */
bool fg_time_decode_rx8900(const uint8_t t[7],uint8_t flag,fg_utc_time *out);
#endif
