#ifndef FG_TZ_DEFAULT_H
#define FG_TZ_DEFAULT_H
#include <stddef.h>
#include <stdint.h>
extern const uint8_t fg_default_tokyo_tzif[];
extern const size_t fg_default_tokyo_tzif_len;
#endif
