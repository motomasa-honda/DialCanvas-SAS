#include "fg_tzif.h"
#include <limits.h>
#include <string.h>
static uint32_t u32be(const uint8_t *p){return ((uint32_t)p[0]<<24)|((uint32_t)p[1]<<16)|((uint32_t)p[2]<<8)|p[3];}
static int64_t i64be(const uint8_t *p){uint64_t v=0;for(int i=0;i<8;i++)v=(v<<8)|p[i];
 if(v<=INT64_MAX)return (int64_t)v;
 /* Avoid implementation-defined unsigned -> signed narrowing. */
 return -1-(int64_t)(UINT64_MAX-v);
}
static bool add_size(size_t a,size_t b,size_t *out){if(SIZE_MAX-a<b)return false;*out=a+b;return true;}
static bool bounded_add(size_t *offset,size_t bytes,size_t limit){size_t out;
 if(!add_size(*offset,bytes,&out)||out>limit)return false;
 *offset=out;return true;
}
bool fg_tz_name_valid(const char *name){
 if(!name||!*name)return false;
 size_t i=0,seg=0;
 for(;name[i];i++){
  unsigned char c=(unsigned char)name[i];if(i>=95)return false;
  bool allowed=(c>='A'&&c<='Z')||(c>='a'&&c<='z')||(c>='0'&&c<='9')||c=='_'||c=='-'||c=='+'||c=='.';
  if(c=='/'){
   if(i==seg||(i-seg==1&&name[seg]=='.')||(i-seg==2&&name[seg]=='.'&&name[seg+1]=='.'))return false;
   seg=i+1;
  } else if(!allowed)return false;
 }
 if(i==seg||(i-seg==1&&name[seg]=='.')||(i-seg==2&&name[seg]=='.'&&name[seg+1]=='.'))return false;
 return true;
}
typedef struct {uint32_t ttisgmt,ttisstd,leap,time,type,ch;} tz_header;
static bool parse_header(const uint8_t *f,size_t len,size_t at,tz_header *h){
 if(at>len||len-at<44||memcmp(f+at,"TZif",4)!=0)return false;
 if(f[at+4]!='2'&&f[at+4]!='3'&&f[at+4]!='4')return false;
 for(int i=5;i<20;i++)if(f[at+i]!=0)return false;
 h->ttisgmt=u32be(f+at+20);h->ttisstd=u32be(f+at+24);h->leap=u32be(f+at+28);
 h->time=u32be(f+at+32);h->type=u32be(f+at+36);h->ch=u32be(f+at+40);
 if(!h->type||h->type>FG_TZ_TYPES||h->time>FG_TZ_TRANSITIONS||h->ch>2048)return false;
 if(h->ttisstd>h->type||h->ttisgmt>h->type||h->leap>1024)return false;
 return true;
}
static bool skip_block(size_t *off,size_t len,tz_header h,unsigned ts,unsigned leap){
 size_t total=0;uint64_t bytes=(uint64_t)h.time*ts+h.time+(uint64_t)h.type*6+h.ch+
                       (uint64_t)h.leap*leap+h.ttisstd+h.ttisgmt;
 if(bytes>SIZE_MAX)return false;
 total=(size_t)bytes;
 return bounded_add(off,total,len);
}
bool fg_tzif_parse(fg_tzif *z,const uint8_t *f,size_t len){
 if(!z||!f)return false;
 memset(z,0,sizeof(*z));fg_tzif *tmp=z;tz_header header;size_t p=0;
 if(!parse_header(f,len,p,&header))return false;
 p=44;if(!skip_block(&p,len,header,4,8))return false;
 if(!parse_header(f,len,p,&header))return false;
 if(!bounded_add(&p,44,len))return false;
 size_t end=p;if(!skip_block(&end,len,header,8,12))return false;
 /* Commit valid-zone marker only after every parsing check succeeds. */
 for(unsigned i=0;i<header.time;i++){
  tmp->at[i]=i64be(f+p+8*i);
  if(i>0&&tmp->at[i]<=tmp->at[i-1])return false;
 }
 p+=(size_t)header.time*8;
 for(unsigned i=0;i<header.time;i++){tmp->type_index[i]=f[p+i];if(tmp->type_index[i]>=header.type)return false;}
 p+=header.time;
 for(unsigned i=0;i<header.type;i++){
  uint32_t v=u32be(f+p+6*i);
  tmp->type[i].utc_offset=v<=INT32_MAX?(int32_t)v:(int32_t)(-(int64_t)(UINT32_MAX-v)-1);
  tmp->type[i].dst=f[p+6*i+4]!=0;
  if(f[p+6*i+4]>1||tmp->type[i].utc_offset<-86400||tmp->type[i].utc_offset>86400||f[p+6*i+5]>=header.ch)return false;
 }
 tmp->initial_type=0;
 for(unsigned i=0;i<header.type;i++)if(!tmp->type[i].dst){tmp->initial_type=i;break;}
 /* RFC 8536 footer: if non-empty POSIX TZ rules exist, do not silently
  * extrapolate a stale DST offset past the final transition. */
 if(end<len&&f[end]=='\n'){
  size_t k=end+1;while(k<len&&f[k]!='\n')k++;
  if(k>=len)return false;
  /* Only a simple fixed-offset footer is safe to extrapolate; DST
   transition rules must be parsed separately before use after the table. */
  bool fixed=true;size_t a=end+1;
  /* POSIX standard abbreviation: alphabetic (or <quoted>); conservative. */
  if(a>=k || (!(f[a]>='A'&&f[a]<='Z') && !(f[a]>='a'&&f[a]<='z')))fixed=false;
  while(a<k&&((f[a]>='A'&&f[a]<='Z')||(f[a]>='a'&&f[a]<='z')))a++;
  if(a==k)fixed=false;
  if(a<k&&(f[a]=='+'||f[a]=='-'))a++;
  size_t digits=a;
  while(a<k&&((f[a]>='0'&&f[a]<='9')||f[a]==':'))a++;
  if(a==digits||a!=k)fixed=false;
  tmp->has_unparsed_posix_tail=(k>end+1)&&!fixed;
 }
 tmp->n_transitions=header.time;tmp->n_types=header.type;return true;
}
bool fg_tzif_offset(const fg_tzif *z,int64_t utc,int32_t *offset,bool *dst){
 if(!z||!offset||!dst||!z->n_types)return false;
 if(z->n_transitions&&utc>z->at[z->n_transitions-1]&&z->has_unparsed_posix_tail)return false;
 unsigned type=z->initial_type;
 if(z->n_transitions&&utc>=z->at[0]){
  unsigned lo=0,hi=z->n_transitions;
  while(lo<hi){unsigned m=lo+(hi-lo)/2;if(z->at[m]<=utc)lo=m+1;else hi=m;}
  type=z->type_index[lo-1];
 }
 if(type>=z->n_types)return false;
 *offset=z->type[type].utc_offset;*dst=z->type[type].dst;return true;
}
static int64_t floor_div(int64_t a,int64_t b){int64_t q=a/b;return a%b<0?q-1:q;}
/* UTC seconds -> Gregorian civil date (1970 epoch), valid across negative epochs. */
static void date_from_days(int64_t days,fg_local_date *out){
 int64_t z=days+719468;
 int64_t era=floor_div(z,146097);
 unsigned doe=(unsigned)(z-era*146097);
 unsigned yoe=(doe-doe/1460+doe/36524-doe/146096)/365;
 int64_t y=(int64_t)yoe+era*400;
 unsigned doy=doe-(365*yoe+yoe/4-yoe/100);
 unsigned mp=(5*doy+2)/153;
 unsigned d=doy-(153*mp+2)/5+1;
 int m=(int)mp+(mp<10?3:-9);
 y+=(m<=2);
 out->year=(int)y;out->month=m;out->day=(int)d;
}
bool fg_tzif_local(const fg_tzif *z,int64_t utc,fg_local_date *out){
 int32_t ofs;bool dst;
 if(!out||!fg_tzif_offset(z,utc,&ofs,&dst))return false;
 if((ofs>0&&utc>INT64_MAX-ofs)||(ofs<0&&utc<INT64_MIN-ofs))return false;
 int64_t sec=utc+ofs,days=floor_div(sec,86400);
 if(days<-719162||days>2932896)return false; /* Gregorian years 1..9999 */
 unsigned rem=(unsigned)(sec-days*86400);
 fg_local_date date={0};date_from_days(days,&date);
 date.hour=(int)(rem/3600);date.minute=(int)((rem%3600)/60);date.second=(int)(rem%60);
 date.offset_seconds=ofs;date.dst=dst;*out=date;return true;
}
