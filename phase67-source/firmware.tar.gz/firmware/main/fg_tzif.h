#ifndef FG_TZIF_H
#define FG_TZIF_H
#include <stdint.h>
#include <stdbool.h>
#include <stddef.h>
#define FG_TZ_TRANSITIONS 1024
#define FG_TZ_TYPES 64
/* Firmware can load TZif v2/v3/v4 files from an explicitly provisioned zone DB.
 * No timezone is silently derived from local host settings. */
typedef struct { int32_t utc_offset; bool dst; } fg_tz_type;
typedef struct {
 int64_t at[FG_TZ_TRANSITIONS];
 uint8_t type_index[FG_TZ_TRANSITIONS];
 fg_tz_type type[FG_TZ_TYPES];
 unsigned n_transitions,n_types,initial_type;
 bool has_unparsed_posix_tail;
} fg_tzif;
typedef struct {int year,month,day,hour,minute,second;int offset_seconds;bool dst;} fg_local_date;
bool fg_tz_name_valid(const char *iana_name);
bool fg_tzif_parse(fg_tzif *zone, const uint8_t *file, size_t len);
/* Returns false beyond last table transition when POSIX future DST rules are required. */
bool fg_tzif_offset(const fg_tzif *zone,int64_t utc_sec,int32_t *offset,bool *dst);
bool fg_tzif_local(const fg_tzif *zone,int64_t utc_sec,fg_local_date *out);
#endif
