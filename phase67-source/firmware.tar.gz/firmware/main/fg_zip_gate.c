/* Forest Guardian strict ZIP structural admission gate. Target-independent C11.
 * Intentionally rejects ZIP data descriptors (flag 3), zip64 and archive comments.
 * THIS IS NOT A COMPLETE DIAL PACKAGE VALIDATOR: full validation must verify
 * DEFLATE, CRC, SHA-256, schema and decoded PNG before any flash commit.
 */
#include "fg_zip_gate.h"
#include <string.h>
#define MAX_ZIP (10u*1024u*1024u)
#define MAX_UNPACK (16u*1024u*1024u)
#define MAX_FILE (4u*1024u*1024u)
#define MAX_FILES 24u
#define CD_SIG 0x02014b50u
#define LH_SIG 0x04034b50u
#define END_SIG 0x06054b50u
static uint16_t u16(const uint8_t *p){return (uint16_t)((uint16_t)p[0]|((uint16_t)p[1]<<8));}
static uint32_t u32(const uint8_t *p){return (uint32_t)p[0]|((uint32_t)p[1]<<8)|((uint32_t)p[2]<<16)|((uint32_t)p[3]<<24);}
static bool addok(size_t a,size_t b,size_t n){return a<=n&&b<=n-a;}
static bool safe_name(const uint8_t *s,size_t n){
 if(!n||n>64||s[0]=='.')return false;
 for(size_t i=0;i<n;i++){
  uint8_t c=s[i];
  if(c=='/'||c=='\\'||c==':'||c<33||c>126)return false;
  if(i&&s[i-1]=='.'&&c=='.')return false;
  if(!((c>='A'&&c<='Z')||(c>='a'&&c<='z')||(c>='0'&&c<='9')||c=='_'||c=='.'||c=='-'))return false;
 }
 return true;
}
typedef struct {const uint8_t *name; uint16_t n; size_t start,end;} ent;
fg_zip_result fg_zip_gate(const uint8_t *p,size_t n){
 if(!p||n<22)return FG_ZIP_INVALID;
 if(n>MAX_ZIP)return FG_ZIP_LIMIT;
 /* Fail closed on archives with trailing bytes or EOCD comments. */
 size_t e=n-22;
 if(u32(p+e)!=END_SIG||u16(p+e+20)!=0)return FG_ZIP_UNSUPPORTED;
 uint16_t disk=u16(p+e+4),cd_disk=u16(p+e+6),n_disk=u16(p+e+8),count=u16(p+e+10);
 uint32_t cd_size=u32(p+e+12),cd_start=u32(p+e+16);
 if(disk||cd_disk||n_disk!=count||count<3||count>MAX_FILES)return FG_ZIP_UNSUPPORTED;
 if(cd_size==UINT32_MAX||cd_start==UINT32_MAX||!addok(cd_start,cd_size,e)||cd_start+cd_size!=e)return FG_ZIP_INVALID;
 ent found[MAX_FILES]; size_t sum=0,pos=cd_start;bool manifest=false,dial=false;
 for(unsigned i=0;i<count;i++){
  if(!addok(pos,46,e)||u32(p+pos)!=CD_SIG)return FG_ZIP_INVALID;
  const uint8_t *c=p+pos;uint16_t made=u16(c+4),flags=u16(c+8),method=u16(c+10);
  uint32_t crc=u32(c+16),comp=u32(c+20),uncomp=u32(c+24),loc=u32(c+42);
  uint16_t fn=u16(c+28),extra=u16(c+30),comment=u16(c+32),ext_disk=u16(c+34);
  (void)crc;
  if(flags&~0x0800u || ext_disk || u16(c+36)!=0 || u16(c+6)>20)return FG_ZIP_UNSUPPORTED;
  if(method!=0&&method!=8)return FG_ZIP_UNSUPPORTED;
  if((made>>8)==3){uint32_t mode=u32(c+38)>>16;uint32_t type=mode&0170000u;
   if(type!=0 && type!=0100000u)return FG_ZIP_UNSUPPORTED;
  }
  if(!addok(pos,46u+(size_t)fn+extra+comment,e))return FG_ZIP_INVALID;
  if(comp==UINT32_MAX||uncomp==UINT32_MAX||loc==UINT32_MAX||uncomp>MAX_FILE||!addok(sum,uncomp,MAX_UNPACK))return FG_ZIP_LIMIT;
  if(method==0 && comp!=uncomp)return FG_ZIP_INVALID;
  sum+=uncomp;
  const uint8_t *name=c+46;
  if(!safe_name(name,fn))return FG_ZIP_INVALID;
  for(unsigned j=0;j<i;j++)if(found[j].n==fn&&!memcmp(name,found[j].name,fn))return FG_ZIP_INVALID;
  if(fn==13&&!memcmp(name,"manifest.json",13))manifest=true;
  if(fn==9&&!memcmp(name,"dial.json",9))dial=true;
  if(!addok(loc,30,cd_start)||u32(p+loc)!=LH_SIG)return FG_ZIP_INVALID;
  const uint8_t *lh=p+loc;uint16_t lfn=u16(lh+26),lextra=u16(lh+28);
  if(u16(lh+4)!=u16(c+6)||u16(lh+6)!=flags||u16(lh+8)!=method||u32(lh+14)!=crc||u32(lh+18)!=comp||u32(lh+22)!=uncomp||lfn!=fn)return FG_ZIP_INVALID;
  if(!addok(loc,30u+(size_t)lfn+lextra,cd_start))return FG_ZIP_INVALID;
  if(memcmp(lh+30,name,fn))return FG_ZIP_INVALID;
  size_t payload=loc+30u+(size_t)lfn+lextra;
  if(!addok(payload,comp,cd_start))return FG_ZIP_INVALID;
  found[i]=(ent){.name=name,.n=fn,.start=loc,.end=payload+comp};
  for(unsigned j=0;j<i;j++){
   if(found[j].start<found[i].end && found[i].start<found[j].end)return FG_ZIP_INVALID;
  }
  pos+=46u+(size_t)fn+extra+comment;
 }
 if(pos!=e||!manifest||!dial)return FG_ZIP_INVALID;
 return FG_ZIP_OK;
}
