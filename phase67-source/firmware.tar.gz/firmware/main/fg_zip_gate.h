#ifndef FG_ZIP_GATE_H
#define FG_ZIP_GATE_H
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
/* Structural admission ONLY. No decompression, CRC, SHA, JSON, PNG or authorization.
   Requires strict validator callback before fg_dial_store_install. */
typedef enum {
 FG_ZIP_OK=0, FG_ZIP_INVALID=1, FG_ZIP_LIMIT=2, FG_ZIP_UNSUPPORTED=3
} fg_zip_result;
fg_zip_result fg_zip_gate(const uint8_t *buf, size_t size);
#endif
